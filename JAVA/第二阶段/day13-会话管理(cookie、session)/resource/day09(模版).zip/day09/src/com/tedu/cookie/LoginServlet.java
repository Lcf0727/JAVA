package com.tedu.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1、获取用户名、密码及是否记住用户标识
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String remUsername = request.getParameter("remUsername");
		
		//2、实现记住用户名或取消记住用户名
		if("yes".equals(remUsername)){//如果勾选了记住用户名复选框
			//创建Cookie对象, 保存用户名
			Cookie remCookie = new Cookie("username",username );
			//设置Cookie的最大存活时间(一年)
			remCookie.setMaxAge(60*60*24*365);
			//将cookie添加到响应中发送给浏览器保存
			response.addCookie(remCookie);
		}else{//如果没有勾选记住用户名, 则删除Cookie(及其中保存的数据)
			/* 发送一个同名的Cookie, 并设置存活时间为零
			 * 浏览器收到后, 后发的cookie会覆盖之前发送的cookie
			 * 由于后发送的cookie存活时间为0,浏览器收到后也会立即删除
			 */
			Cookie remCookie = new Cookie("username","");
			remCookie.setMaxAge(0);
			response.addCookie(remCookie);
		}
		
		/* 3、模拟登录功能（当用户名为"zhangfei", 密码为"123"时允许用户登陆）
		 */
		if("zhangfei".equals(username) && 
			"123".equals(password)){ 
			//用户名密码正确: 获取session, 将用户名保存到session中
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			//登录成功, 跳转到网站首页
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		}else{ //登录失败, 提示用户名用户名或密码错误
			response.setContentType("text/html;charset=utf-8");
			PrintWriter pw = response.getWriter();
			pw.write("<script>alert('用户名或密码输入错误, 2秒后将会跳转回登陆页面...')</script>");
			//定时刷新:2秒后跳转到登录页面
			response.setHeader("Refresh", "2;url="+request.getContextPath()+"/login.jsp");
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
