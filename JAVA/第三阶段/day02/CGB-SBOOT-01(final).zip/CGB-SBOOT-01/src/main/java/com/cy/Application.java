package com.cy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * Spring Boot项目中由@SpringBootApplication注解描述的类为系统启动类,
 * 这个类在启动时会自动:
 * 1)扫描本类所在包以及子包中的类,并查找由spring容器管理的对象(@Controller,@Service,...)
 * 2)进行资源的默认初始化配置(自动配置),具备配置会参考spring.factories(此文件所在的jar包
 * 为spring-boot-autoconfigure-2.2.2.RELEASE.jar)
 */
@SpringBootApplication
public class Application {
    static {//static代码块执行表示类会被加载,但是类加载时不一定会执行静态代码块.
    	System.out.println("static{}");
    }
	public static void main(String[] args) {
        System.out.println("main()");		
		SpringApplication.run(Application.class, args);
	}
}











