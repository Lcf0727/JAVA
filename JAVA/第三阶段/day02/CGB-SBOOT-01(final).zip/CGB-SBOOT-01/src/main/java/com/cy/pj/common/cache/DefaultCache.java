package com.cy.pj.common.cache;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/**
 * 使用Spring框架指定注解(例如@Component)对类进行描述,
 * 表示此类是一个要交给Spring容器管理的对象.
 * 思考:Spring框架中描述Bean对象的常用注解的有哪些?
 * 1)@Component (描述一般组件对象)
 * 2)@Controller (描述控制层对象)
 * 3)@Service(描述业务层对象)
 * 4)@Repository(描述数据层对象)
 * 5)@Configuration(描述配置对象)
 * 6).....
 * 说明:使用什么注解对类进行描述,基于程序员设计的规则进行实现.
 */
//@Scope("prototype")//prototype作用域表示每次从容器获取对象都会创建一个新的实例,当使用此作用域时,没必要再使用@Lazy注解
@Scope("singleton")//@Scope注解用于指定类实例的作用域,Singleton表示单例作用域(整个内存此类实例只有一份).
//@Lazy//当类使用@Lazy注解描述时,表示此类要使用延迟加载特性,true表示延迟加载
@Component //<bean id="defaultCache" class="com.cy.pj.common.cache.DefaultCache">
public class DefaultCache {
	public DefaultCache() {
		System.out.println("DefaultCache()");
	}
	/**
	 * 假如一个类的实例需要有对象的初始化方法和销毁方法,我们可以
	 * 借助如下两个注解对相关方法进行描述:
	 * 1)@PostConstruct 注解描述的方法在构造方法执行之后执行
	 * 2)@PreDestroy 注解描述的方法在对象销毁之前执行.
	 * 说明:每个对象都有生命周期,但不见得每个对象都有生命周期方法.一般一些
	 * 池对象会设计一些生命周期方法,例如连接池,线程池等.
	 */
	@PostConstruct
	public void init() {
		System.out.println("init()");
	}
	@PreDestroy
	public void destory() {
		System.out.println("destory()");
	}
}

















