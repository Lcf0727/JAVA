package com.cy.pj.common.test;

import java.io.PrintStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cy.pj.common.cache.DefaultCache;

@SpringBootTest
public class CacheTests {//is a Object

	//has a (有一个)
	@Autowired
	private DefaultCache defaultCache;
	
	@Test
	public void testDefaultCache() {
		//System.out.println(defaultCache);
		//use a PrintStream
		//use a System
		PrintStream ps=System.out;
		ps.println(defaultCache);
	}
}
