package com.cy;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.cy.pj.common.cache.DefaultCache;

/**
 * Spring Boot项目中的所有测试类需要使用@SpringBootTest修饰
 * ,使用此注解修饰的类,在测试阶段会交给spring容器管理.
 */
@SpringBootTest
class ApplicationTests {
	@Autowired //描述属性并告诉spring框架,此属性的值由spring容器进行注入
	private BeanFactory beanFactory;
	
	@Autowired
	private ApplicationContext  applicationContext;
	/**
	 * 测试spring容器启动时创建的bean工厂的具体类型
	 */
	@Test
	public void testBeanFactory() {
		//DefaultListableBeanFactory
		System.out.println(beanFactory.getClass().getName());
	}
	@Test
	public void testApplicationContext() {
		//AnnotationConfigApplicationContext
		System.out.println(applicationContext.getClass().getName());
	}
	
	@Test
	public void testGetBean() {
		DefaultCache cache1=
		applicationContext.getBean("defaultCache",DefaultCache.class);
		System.out.println(cache1);
		DefaultCache cache2=
		applicationContext.getBean("defaultCache",DefaultCache.class);
		System.out.println(cache1==cache2);
	}
}




